#!/bin/bash

# --- FUNCTIONS ---

cpu() {
    model=$(grep -m1 "model name" /proc/cpuinfo | cut -d: -f2 | sed 's/^ //')
    echo "CPU: $model"
}

ram() {
    ram=$(free -m | awk 'NR==2 {printf "%s/%s MiB (%.0f%% used)\n", $3, $2, ($3/$2*100)}')
    echo "RAM: $ram"
}

loadavg() {
    echo "Load: $(cut -d ' ' -f1-3 /proc/loadavg)"
}

uptime_info() {
    # uptime w minutach / godzinach
    uptime -p | sed 's/up //; s/,//g' | awk '
    {
        out="";
        for (i=1; i<=NF; i+=2)
            out = out $i " " $(i+1) ", ";
        sub(", $","",out);
        print "Uptime: " out;
    }'
}

kernel() {
    echo "Kernel: $(uname -r)"
}

gpu() {
    echo -n "GPU: "
    lspci | grep -i 'vga\|3d\|display' | head -n1 | cut -d: -f3- | sed 's/^ //'
}

user_info() {
    echo "User: $USER"
}

shell_info() {
    echo "Shell: $(basename "$SHELL")"
}

processes() {
    echo "Processes: $(ps -e --no-headers | wc -l)"
}

threads() {
    echo "Threads: $(ps -eLo tid --no-headers | wc -l)"
}

ip_info() {
    echo -n "IP: "
    ip -o -4 addr show | awk '{print $4}' | paste -sd " " -
}

dns() {
    echo -n "DNS: "
    grep -m1 "nameserver" /etc/resolv.conf | awk '{print $2}'
}

internet() {
    if timeout 1 ping -c1 8.8.8.8 &>/dev/null; then
        echo "Internet: OK"
    else
        echo "Internet: DOWN"
    fi
}


declare -A FUNCS=(
    ["CPU"]=cpu
    ["RAM"]=ram
    ["LOAD"]=loadavg
    ["UPTIME"]=uptime_info
    ["KERNEL"]=kernel
    ["GPU"]=gpu
    ["USER"]=user_info
    ["SHELL"]=shell_info
    ["PROCESSES"]=processes
    ["THREADS"]=threads
    ["IP"]=ip_info
    ["DNS"]=dns
    ["INTERNET"]=internet
)

# --- ARGUMENTS ---

print_all() {
    cpu
    ram
    loadavg
    uptime_info
    kernel
    gpu
    user_info
    shell_info
    processes
    threads
    ip_info
    dns
    internet
}

if [ $# -eq 0 ]; then
    print_all
    exit 0
fi

status=0

for arg in "$@"; do
    key=$(echo "$arg" | tr '[:lower:]' '[:upper:]')

    if [[ -n "${FUNCS[$key]}" ]]; then
        ${FUNCS[$key]}
    else
        echo "Błędny argument: $arg" >&2
        status=1
    fi
done

exit $status

