#!/bin/bash

# --- FUNCTIONS ---

list_top_cpu() {
    echo "Top 5 processes by CPU usage:"
    ps aux --sort=-%cpu | head -n 6
}

list_top_memory() {
    echo "Top 5 processes by memory usage:"
    ps aux --sort=-%mem | head -n 6
}

show_process_tree() {
    echo "Process Tree:"
    pstree
}

show_process_by_pid() {
    read -p "Enter PID: " pid
    if ps -p $pid > /dev/null; then
        process_name=$(ps -p $pid -o comm=)
        echo "Process name for PID $pid: $process_name"
    else
        echo "No process found with PID $pid"
    fi
}

show_pid_by_name() {
    read -p "Enter process name: " process_name
    pids=$(pgrep -f "$process_name")
    if [ -z "$pids" ]; then
        echo "No process found with name $process_name"
    else
        echo "PIDs for process $process_name: $pids"
    fi
}

kill_process_by_pid() {
    read -p "Enter PID to kill: " pid
    if ps -p $pid > /dev/null; then
        kill $pid
        echo "Process with PID $pid has been killed."
    else
        echo "No process found with PID $pid"
    fi
}

kill_process_by_name() {
    read -p "Enter process name to kill: " process_name
    pids=$(pgrep -f "$process_name")
    if [ -z "$pids" ]; then
        echo "No process found with name $process_name"
    else
        kill $pids
        echo "Processes with name $process_name have been killed."
    fi
}

# --- MAIN MENU ---

while true; do
    echo "Process Control:"
    echo "1) List top 5 processes by CPU usage"
    echo "2) List top 5 processes by memory usage"
    echo "3) Show process tree"
    echo "4) Show process name by PID"
    echo "5) Show process PID(s) by name"
    echo "6) Kill process by PID"
    echo "7) Kill process by name"
    echo "q) Exit"
    read -p "Choice: " choice

    case $choice in
        1) list_top_cpu ;;
        2) list_top_memory ;;
        3) show_process_tree ;;
        4) show_process_by_pid ;;
        5) show_pid_by_name ;;
        6) kill_process_by_pid ;;
        7) kill_process_by_name ;;
        q) exit 0 ;;
        *) echo "Invalid choice, please try again." ;;
    esac

    echo ""
done

